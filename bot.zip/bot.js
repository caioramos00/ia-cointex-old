const axios = require('axios');
const OpenAI = require('openai');
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const { getActiveTransport } = require('./lib/transport');
const { atualizarContato, getBotSettings, pool, getContatoByPhone } = require('./db');
const { promptClassificaAceite, promptClassificaAcesso, promptClassificaConfirmacao, promptClassificaRelevancia, promptClassificaOptOut, promptClassificaReoptin } = require('./prompts.js');
const estadoContatos = require('./state.js');

const EXTRA_FIRST_REPLY_BASE_MS = 45000;
const EXTRA_FIRST_REPLY_JITTER_MS = 10000;
const GLOBAL_PER_MSG_BASE_MS = 3000;
const GLOBAL_PER_MSG_JITTER_MS = 1500;


const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const OPTOUT_RX = /\b(pare|para(?!\w)|parar|não quero|nao quero|me remove|remova|me tira|me exclui|excluir|cancelar|unsubscribe|cancel|stop|parem|não mandar|nao mandar)\b/i;

const MAX_OPTOUTS = 3;
const OPTOUT_MSGS = {
    1: 'tranquilo, não vou mais te mandar mensagem. qualquer coisa só chamar',
    2: 'de boa, vou passar o trampo pra outra pessoa e não te chamo mais. não me manda mais mensagem',
};

async function setDoNotContact(contato, value = true) {
    try {
        await pool.query('UPDATE contatos SET do_not_contact = $2 WHERE id = $1', [contato, !!value]);
        console.log(`[${contato}] do_not_contact atualizado para ${!!value}`);
        if (!value) cancelarConfirmacaoOptOut(contato);
    } catch (e) {
        console.error(`[${contato}] Falha ao setar do_not_contact: ${e.message}`);
    }
}

async function finalizeOptOut(contato, reasonText = '') {
    let permanently = false;

    try {
        const { rows } = await pool.query(
            'SELECT opt_out_count, permanently_blocked FROM contatos WHERE id = $1 LIMIT 1',
            [contato]
        );
        if (rows?.[0]?.permanently_blocked || (rows?.[0]?.opt_out_count || 0) >= MAX_OPTOUTS) return;

        const next = (rows?.[0]?.opt_out_count || 0) + 1;
        permanently = next >= MAX_OPTOUTS;

        await pool.query(`
      UPDATE contatos
         SET do_not_contact = TRUE,
             do_not_contact_at = NOW(),
             do_not_contact_reason = $2,
             opt_out_count = $3,
             permanently_blocked = $4
       WHERE id = $1
    `, [contato, String(reasonText || '').slice(0, 200), next, permanently]);

        const st = estadoContatos[contato] || {};
        if (st?._timer2Abertura) clearTimeout(st._timer2Abertura);
        if (st?.merrecaTimeout) clearTimeout(st.merrecaTimeout);
        if (st?.posMerrecaTimeout) clearTimeout(st.posMerrecaTimeout);

        if (estadoContatos[contato]) {
            estadoContatos[contato].cancelarEnvio = true;
            estadoContatos[contato].enviandoMensagens = false;
            estadoContatos[contato].mensagensPendentes = [];
            if (permanently) {
                estadoContatos[contato].etapa = 'encerrado';
                delete estadoContatos[contato].seqLines;
                delete estadoContatos[contato].seqIdx;
                estadoContatos[contato].paused = false;
            } else {
                estadoContatos[contato].paused = true;
            }
        }

        if (!permanently) {
            // agenda confirmação CANCELÁVEL
            cancelarConfirmacaoOptOut(contato);
            const delayMs = rand(10000, 15000);
            const timer = setTimeout(async () => {
                try {
                    const { rows: r } = await pool.query(
                        'SELECT do_not_contact, permanently_blocked FROM contatos WHERE id = $1 LIMIT 1',
                        [contato]
                    );
                    if (!r?.[0]?.do_not_contact || r?.[0]?.permanently_blocked) return;
                    await sendMessage(contato, OPTOUT_MSGS[next] || OPTOUT_MSGS[2], { bypassBlock: true });
                } finally {
                    const st2 = estadoContatos[contato];
                    if (st2) st2._optoutTimer = null;
                }
            }, delayMs);
            if (estadoContatos[contato]) estadoContatos[contato]._optoutTimer = timer;
        }
    } catch (e) {
        console.error(`[${contato}] Falha ao registrar opt-out: ${e.message}`);
    }

    console.log(`[${contato}] Opt-out concluído (${permanently ? 'permanente' : 'temporário'}).`);
}

async function checarOptOutGlobal(contato, mensagens) {
    try {
        const arr = Array.isArray(mensagens) ? mensagens : [String(mensagens || '')];

        for (const txt of arr) {
            const texto = String(txt || '').trim();
            // 1) regex rápido
            if (OPTOUT_RX.test(texto)) {
                await finalizeOptOut(contato, texto);
                console.log(`[${contato}] Opt-out detectado via REGEX em: "${texto}"`);
                return true;
            }
            // 2) IA (se qualquer UMA for OPTOUT, para tudo)
            const out = await gerarResposta(
                [{ role: 'system', content: promptClassificaOptOut(texto) }],
                ['OPTOUT', 'CONTINUAR']
            );
            if (String(out || '').trim().toUpperCase() === 'OPTOUT') {
                await finalizeOptOut(contato, texto);
                console.log(`[${contato}] Opt-out detectado via LLM em: "${texto}"`);
                return true;
            }
        }

        console.log(`[${contato}] Sem opt-out nas mensagens analisadas.`);
        return false;
    } catch (err) {
        console.error(`[${contato}] Erro em checarOptOutGlobal:`, err?.message || err);
        return false;
    }
}

function cancelarConfirmacaoOptOut(contato) {
    const st = estadoContatos[contato];
    if (st && st._optoutTimer) {
        clearTimeout(st._optoutTimer);
        st._optoutTimer = null;
        console.log(`[${contato}] Confirmação de opt-out pendente CANCELADA.`);
    }
}

async function retomarEnvio(contato) {
    const st = estadoContatos[contato];
    if (!st || !Array.isArray(st.seqLines)) {
        console.log(`[${contato}] Nada para retomar (sem seqLines).`);
        return false;
    }

    const startIdx = st.seqIdx || 0;
    const remaining = st.seqLines.slice(startIdx).join('\n');
    if (!remaining.trim()) {
        delete st.seqLines;
        delete st.seqIdx;
        st.paused = false;
        console.log(`[${contato}] Nada para retomar (sequência já concluída).`);
        return false;
    }

    await delay(rand(10000, 15000));

    try {
        const { rows } = await pool.query(
            'SELECT opt_out_count FROM contatos WHERE id = $1 LIMIT 1',
            [contato]
        );
        const count = rows?.[0]?.opt_out_count || 0;

        let retomadaMsg = null;
        if (count === 1) {
            retomadaMsg = 'certo, vamos continuar então';
        } else if (count >= 2) {
            retomadaMsg = 'última chance, se não for fazer já me avisa pq não posso ficar perdendo tempo não, vou tentar continuar de novo aqui, vamos lá';
        }

        if (retomadaMsg) {
            await sendMessage(contato, retomadaMsg);
            try {
                await atualizarContato(contato, 'Sim', st.etapa || 'retomada', retomadaMsg);
                st.historico?.push?.({ role: 'assistant', content: retomadaMsg });
            } catch (e) {
                console.error(`[${contato}] Falha ao logar mensagem de retomada: ${e.message}`);
            }
        }
    } catch (e) {
        console.error(`[${contato}] Falha ao buscar opt_out_count para retomada: ${e.message}`);
    }

    st.cancelarEnvio = false;
    st.paused = false;

    await enviarLinhaPorLinha(contato, remaining);
    if (!st.seqLines && st.seqKind === 'credenciais') {
        st.credenciaisEntregues = true;
        st.seqKind = null;
        console.log(`[${contato}] Credenciais concluídas na retomada.`);
    }
    return true;
}

function toUpperSafe(x) { return String(x || "").trim().toUpperCase(); }

function normalizeAllowedLabels(allowedLabels) {
    if (Array.isArray(allowedLabels)) return allowedLabels.map(toUpperSafe).filter(Boolean);
    if (typeof allowedLabels === "string") return allowedLabels.split(/[|,]/).map(toUpperSafe).filter(Boolean);
    return [];
}

function pickValidLabel(text, allowed) {
    if (!allowed.length) return null;
    const first = String(text || "").trim().split(/\s+/)[0];
    const u = toUpperSafe(first);
    return allowed.includes(u) ? u : null;
}

function extractJsonLabel(outputText, allowed) {
    try {
        const obj = JSON.parse(outputText || "{}");
        return pickValidLabel(obj.label, allowed);
    } catch { return null; }
}

async function gerarResposta(messages, allowedLabels) {
    const allow = normalizeAllowedLabels(allowedLabels || []);
    const DEFAULT_LABEL = allow.includes("CONTINUAR") ? "CONTINUAR" : (allow[0] || "UNKNOWN");

    try {
        const promptStr = messages.map(m => m.content).join("\n");

        const promptJson = `${promptStr}

Retorne estritamente JSON, exatamente neste formato:
{"label":"${allow.join("|").toLowerCase()}"}`;

        let res = await openai.responses.create({
            model: "gpt-5",
            input: promptJson,
            max_output_tokens: 24  // (mínimo aceito é 16)
            // não envie temperature/top_p/stop (snapshots do gpt-5 podem rejeitar)
        });

        let outText = String(res.output_text || "").trim();
        let label = extractJsonLabel(outText, allow);

        // 2) Fallback: se não for JSON válido, peça 1 palavra e valide
        if (!label) {
            res = await openai.responses.create({
                model: "gpt-5",
                input: `${promptStr}\n\nResponda APENAS com UMA palavra válida: ${allow.join("|")}`,
                max_output_tokens: 24
            });
            const raw = String(res.output_text || "").trim();
            label = pickValidLabel(raw, allow);
        }

        return label || DEFAULT_LABEL;
    } catch (err) {
        console.error("[OpenAI] Erro:", err?.message || err);
        return DEFAULT_LABEL; // não quebra seu fluxo
    }
}

async function decidirOptLabel(texto) {
    const raw = String(texto || '').trim();

    const HARD_STOP = /\b(?:stop|unsubscribe|remover|remova|remove|excluir|exclui(?:r)?|cancelar|cancela|cancelamento|para(?!\w)|parem|pare|nao quero|não quero|não me chame|nao me chame|remove meu número|remova meu numero|golpe|golpista|crime|criminoso|denunciar|denúncia|policia|polícia|federal|civil)\b/i;

    if (HARD_STOP.test(raw)) return 'OPTOUT';

    // Fast-path de retomada para frases batidas (não substitui a IA; só agiliza)
    const norm = raw.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase();
    const RE_PHRASES = [
        'mudei de ideia', 'quero fazer', 'quero sim', 'vou querer sim',
        'pode continuar', 'pode seguir', 'pode mandar', 'pode prosseguir', 'pode enviar',
        'vamos', 'vamo', 'bora', 'to dentro', 'tô dentro', 'topo', 'fechou', 'fechado', 'partiu', 'segue'
    ];
    if (RE_PHRASES.some(p => norm.includes(p))) return 'REOPTIN';

    // 1) seu prompt de OPT-OUT (com todas as palavras que você exigiu)
    try {
        const r1 = await gerarResposta(
            [{ role: 'system', content: promptClassificaOptOut(raw) }],
            ['OPTOUT', 'CONTINUAR']
        );
        if (String(r1 || '').trim().toUpperCase() === 'OPTOUT') return 'OPTOUT';
    } catch { }

    // 2) não sendo opt-out → seu prompt de RE-OPT-IN
    try {
        const r2 = await gerarResposta(
            [{ role: 'system', content: promptClassificaReoptin(raw) }],
            ['REOPTIN', 'CONTINUAR']
        );
        if (String(r2 || '').trim().toUpperCase() === 'REOPTIN') return 'REOPTIN';
    } catch { }

    // 3) default
    return 'CONTINUAR';
}

function gerarSenhaAleatoria() {
    return Math.floor(1000 + Math.random() * 9000).toString();
}

async function enviarLinhaPorLinha(to, texto) {
    const estado = estadoContatos[to];
    if (!estado) {
        console.log(`[${to}] Erro: Estado não encontrado em enviarLinhaPorLinha`);
        return;
    }

    try {
        const { rows } = await pool.query(
            'SELECT do_not_contact, opt_out_count, permanently_blocked FROM contatos WHERE id = $1 LIMIT 1',
            [to]
        );
        const f = rows?.[0] || {};
        if (f.permanently_blocked || (f.opt_out_count || 0) >= MAX_OPTOUTS || f.do_not_contact) {
            console.log(`[${to}] Bloqueado antes do envio (DNC/limite).`);
            return;
        }
    } catch (e) {
        console.error(`[${to}] Falha ao checar bloqueio antes do envio: ${e.message}`);
        return;
    }

    // Selo de identidade (apenas na 1ª resposta da abertura)
    try {
        const isFirstResponse = (estado.etapa === 'abertura' && !estado.aberturaConcluida);
        if (isFirstResponse) {
            const settings = await getBotSettings().catch(() => null);
            const enabled = settings?.identity_enabled !== false;
            let label = (settings?.identity_label || '').trim();

            if (!label) {
                const pieces = [];
                if (settings?.support_email) pieces.push(settings.support_email);
                if (settings?.support_phone) pieces.push(settings.support_phone);
                if (settings?.support_url) pieces.push(settings.support_url);
                if (pieces.length) label = `Suporte • ${pieces.join(' | ')}`;
            }

            if (enabled && label) {
                texto = `${label}\n${texto}`;
            }
        }
    } catch (e) {
        console.error('[SeloIdent] Falha ao avaliar/preparar label:', e.message);
    }

    // Sufixo de opt-out (apenas na 1ª resposta da abertura)
    try {
        const isFirstResponse = (estado.etapa === 'abertura' && !estado.aberturaConcluida);
        if (isFirstResponse) {
            const settings = await getBotSettings().catch(() => null);
            const optHintEnabled = settings?.optout_hint_enabled !== false; // default ON
            const suffix = (settings?.optout_suffix || '· se não quiser: NÃO QUERO').trim();

            if (optHintEnabled && suffix) {
                const linhasTmp = texto.split('\n');
                // pega a última linha não-vazia
                let idx = linhasTmp.length - 1;
                while (idx >= 0 && !linhasTmp[idx].trim()) idx--;
                if (idx >= 0 && !linhasTmp[idx].includes(suffix)) {
                    linhasTmp[idx] = `${linhasTmp[idx]} ${suffix}`;
                    texto = linhasTmp.join('\n');
                }
            }
        }
    } catch (e) {
        console.error('[OptOutHint] Falha ao anexar sufixo:', e.message);
    }

    // Envio linha a linha com memória de progresso (seqLines/seqIdx)
    console.log(`[${to}] Iniciando envio de mensagem: "${texto}"`);

    await delay(10000); // pacing inicial

    const linhas = texto.split('\n').filter(line => line.trim() !== '');

    // snapshot da sequência no estado (só recria se o conteúdo mudou)
    if (!Array.isArray(estado.seqLines) || estado.seqLines.join('\n') !== linhas.join('\n')) {
        estado.seqLines = linhas.slice();
        estado.seqIdx = 0; // começa do início desta sequência
    }

    for (let i = estado.seqIdx || 0; i < estado.seqLines.length; i++) {
        const linha = estado.seqLines[i];
        try {
            // 🛑 checkpoints de cancelamento/pausa
            if (estado.cancelarEnvio || estado.paused) {
                console.log(`[${to}] Loop interrompido: cancelarEnvio/paused=true.`);
                estado.enviandoMensagens = false;
                return; // mantém seqIdx para retomar
            }

            // 🛑 rechecar bloqueio entre linhas (DNC/limite)
            try {
                const { rows } = await pool.query(
                    'SELECT do_not_contact, opt_out_count, permanently_blocked FROM contatos WHERE id = $1 LIMIT 1',
                    [to]
                );
                const f = rows?.[0] || {};
                if (f.permanently_blocked || (f.opt_out_count || 0) >= MAX_OPTOUTS || f.do_not_contact) {
                    console.log(`[${to}] Loop interrompido: bloqueado entre linhas (DNC/limite).`);
                    estado.enviandoMensagens = false;
                    return;
                }
            } catch (e) {
                console.error(`[${to}] Falha ao checar bloqueio entre linhas: ${e.message}`);
                estado.enviandoMensagens = false;
                return;
            }

            await delay(Math.max(500, linha.length * 30));
            await sendMessage(to, linha);
            estado.seqIdx = i + 1; // avançou uma linha
            await delay(7000 + Math.floor(Math.random() * 1000));
        } catch (error) {
            console.error(`[${to}] Erro ao enviar linha "${linha}": ${error.message}`);
            estado.enviandoMensagens = false;
            return;
        }
    }

    // sequência concluída — limpar snapshot
    delete estado.seqLines;
    delete estado.seqIdx;
    estado.paused = false;
}


async function sendManychatBatch(phone, textOrLines) {
    const settings = await getBotSettings().catch(() => ({}));
    const token =
        process.env.MANYCHAT_API_TOKEN ||
        process.env.MANYCHAT_API_KEY ||
        settings.manychat_api_token;
    if (!token) throw new Error('ManyChat: token ausente');

    const contato = await getContatoByPhone(phone).catch(() => null);
    const subscriberId =
        contato?.manychat_subscriber_id ||
        estadoContatos[phone]?.manychat_subscriber_id ||
        null;
    if (!subscriberId) {
        console.warn(`[ManyChat] subscriberId ausente para ${phone} — pulando envio externo (simulação/local).`);
        return { ok: true, skipped: true, reason: 'no-subscriber' };
    }

    const payloadItems = Array.isArray(textOrLines)
        ? textOrLines.map(s => String(s))
        : [String(textOrLines)];
    const messages = payloadItems.slice(0, 10).map(t => ({ type: 'text', text: t }));
    if (!messages.length) return { skipped: true };

    const basePayload = {
        subscriber_id: Number(subscriberId),
        data: { version: 'v2', content: { type: 'whatsapp', messages } }
    };

    async function postMC(path, payload, label) {
        const url = `https://api.manychat.com${path}`;
        console.log(`[ManyChat][${label}] POST ${url}`);
        console.log(`[ManyChat][${label}] Payload: ${JSON.stringify(payload)}`);
        const resp = await axios.post(url, payload, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json',
                Accept: 'application/json'
            },
            validateStatus: () => true
        });
        const brief = typeof resp.data === 'string' ? resp.data.slice(0, 300) : resp.data;
        console.log(`[ManyChat][${label}] HTTP ${resp.status} Body: ${JSON.stringify(brief)}`);

        if (resp.status >= 400 || resp.data?.status === 'error') {
            const err = new Error(`${label} falhou: HTTP ${resp.status}`);
            err.httpStatus = resp.status;
            err.body = resp.data;
            throw err;
        }
        return resp.data;
    }

    try {
        // ✅ SEMPRE usar o namespace /fb (mesmo pro WhatsApp)
        return await postMC('/fb/sending/sendContent', basePayload, 'sendContent/fb');
    } catch (e) {
        // Janela de 24h estourada → usar Flow (template)
        const code = e.body?.code;
        const msg = (e.body?.message || '').toLowerCase();
        const is24h = code === 3011 || /24|window|tag/.test(msg);

        if (!is24h) throw e;

        const flowNs = settings.manychat_fallback_flow_id || process.env.MANYCHAT_FALLBACK_FLOW_ID;
        if (!flowNs) {
            throw new Error('ManyChat: fora da janela e MANYCHAT_FALLBACK_FLOW_ID não configurado.');
        }

        const flowPayload = { subscriber_id: Number(subscriberId), flow_ns: flowNs };
        return await postMC('/fb/sending/sendFlow', flowPayload, 'sendFlow/fb');
    }
}

async function sendMessage(to, text, opts = {}) {
    const { bypassBlock = false } = opts;

    if (typeof text === 'function') {
        try { text = text(); } catch (e) { text = String(text); }
    }

    let extraWait = GLOBAL_PER_MSG_BASE_MS + Math.floor(Math.random() * GLOBAL_PER_MSG_JITTER_MS);
    const st = estadoContatos[to];
    if (st?.primeiraRespostaPendente) {
        extraWait += EXTRA_FIRST_REPLY_BASE_MS + Math.floor(Math.random() * EXTRA_FIRST_REPLY_JITTER_MS);
        st.primeiraRespostaPendente = false;
    }
    await delay(extraWait);

    if (!bypassBlock) {
        try {
            const { rows } = await pool.query(
                'SELECT do_not_contact, opt_out_count, permanently_blocked FROM contatos WHERE id = $1 LIMIT 1',
                [to]
            );
            const f = rows?.[0] || {};
            if (f.permanently_blocked || (f.opt_out_count || 0) >= MAX_OPTOUTS || f.do_not_contact) {
                console.log(`[${to}] Envio cancelado (DNC/limite).`);
                return { skipped: true, reason: 'blocked' };
            }
        } catch (e) {
            console.error(`[${to}] Falha ao re-checar bloqueio antes do envio: ${e.message}`);
            return { skipped: true, reason: 'db_error' };
        }
    }

    const { mod: transport, settings } = await getActiveTransport();

    if (transport.name === 'manychat') {
        const payloadItems = Array.isArray(text) ? text.map(String) : [String(text)];
        return await sendManychatBatch(to, payloadItems);
    }

    if (transport.name === 'twilio') {
        const sanitized = to.replace(/^whatsapp:/, '');
        return transport.sendText({ to: sanitized, text }, settings);
    }

    return transport.sendText({ to, text }, settings);
}

function inicializarEstado(contato, tid = '', click_type = 'Orgânico') {
    estadoContatos[contato] = {
        etapa: 'abertura',
        primeiraRespostaPendente: true,
        historico: [],
        encerrado: false,
        ultimaMensagem: Date.now(),
        credenciais: null,
        credenciaisEntregues: false,
        instrucoesConcluida: false,
        instrucoesSequenciada: false,
        instrMsg1Enviada: false,
        instrMsg2Enviada: false,
        instrMsg3Enviada: false,
        acessoMsgsDisparadas: false,
        acessoMsg1Enviada: false,
        acessoMsg2Enviada: false,
        acessoMsg3Enviada: false,
        aguardandoAceiteInstrucoes: false,
        mensagensPendentes: [],
        mensagensDesdeSolicitacao: [],
        saqueInstrucoesEnviadas: false,
        validacaoMsgInicialEnviada: false,
        validacaoRecebeuMidia: false,
        aguardandoPrint: false,
        negativasAbertura: 0,
        aberturaConcluida: false,
        instrucoesEnviadas: false,
        encerradoAte: null,
        aguardandoAcompanhamento: false,
        tentativasAcesso: 0,
        saqueInstrucoesEnviadas: false,
        tentativasConfirmacao: 0,
        saldo_informado: null,
        mensagemDelayEnviada: false,
        enviandoMensagens: false,
        confirmacaoMsgInicialEnviada: false,
        instrucoesCompletas: false,
        aguardandoPrint: false,
        tid: tid,
        click_type: click_type,
        capiContactSent: false
    };
    atualizarContato(contato, 'Sim', 'abertura');
    console.log(`[${contato}] Estado inicializado e contato atualizado: Sim, abertura. TID: ${tid}, click_type: ${click_type}`);
}

async function criarUsuarioDjango(contato) {
    const DJANGO_API_URL = process.env.DJANGO_API_URL || 'https://www.cointex.cash/api/create-user/';

    const st = estadoContatos[contato] || {};
    const tid = st.tid || '';
    const click_type = st.click_type || 'Orgânico';

    // normaliza para E.164 com +
    const phone_e164 = /^\+/.test(contato) ? contato : `+${contato}`;

    const body = { tid, click_type, phone_number: phone_e164 };

    const MAX_TRIES = 3;
    let lastErr;

    for (let attempt = 1; attempt <= MAX_TRIES; attempt++) {
        try {
            console.log(`[${contato}] Enviando para API Cointex (tentativa ${attempt}/${MAX_TRIES}):`, JSON.stringify(body));

            const resp = await axios.post(DJANGO_API_URL, body, {
                headers: { 'Content-Type': 'application/json' },
                timeout: 15000,
                validateStatus: () => true
            });

            console.log(`[${contato}] Cointex HTTP ${resp.status}`, resp.data);

            // retry específico pro bug "cannot access local variable 'phone_number'..."
            const retriable500 =
                resp.status === 500 &&
                typeof resp.data?.message === 'string' &&
                /cannot access local variable 'phone_number'/i.test(resp.data.message);

            if (retriable500) {
                await delay(250 + Math.floor(Math.random() * 750));
                continue; // tenta novamente
            }

            if (resp.status < 200 || resp.status >= 300) {
                throw new Error(`Cointex retornou ${resp.status}`);
            }

            const data = resp.data || {};
            if (data.status === 'success' && Array.isArray(data.users) && data.users[0]) {
                const u = data.users[0];
                estadoContatos[contato].credenciais = {
                    username: u.email,
                    password: u.password,
                    link: u.login_url
                };
                console.log(`[${contato}] Usuário criado: ${u.email}`);
            } else {
                console.error(`[${contato}] Resposta inesperada da API Cointex: ${JSON.stringify(data)}`);
            }
            return; // sucesso
        } catch (err) {
            lastErr = err;
            console.error(`[${contato}] Erro na API Django (tentativa ${attempt}/${MAX_TRIES}): ${err.message}`);
            await delay(300 + Math.floor(Math.random() * 900)); // backoff simples
        }
    }

    if (lastErr) {
        console.error(`[${contato}] Falha definitiva ao criar usuário na Cointex: ${lastErr.message}`);
    }
}

async function processarMensagensPendentes(contato) {
    try {
        const estado = estadoContatos[contato];

        if (estado && (estado.merrecaTimeout || estado.posMerrecaTimeout)) {
            console.log(`[${contato}] Ignorando mensagens durante timeout (merreca/posMerreca)`);
            estado.mensagensPendentes = [];
            return;
        }

        if (!estado || estado.enviandoMensagens) {
            console.log(`[${contato}] Bloqueado: estado=${!!estado}, enviandoMensagens=${estado && estado.enviandoMensagens}`);
            return;
        }
        estado.enviandoMensagens = true;

        console.log(`[${contato}] etapa=${estado.etapa} acessoMsgsDisparadas=${estado.acessoMsgsDisparadas} credEnt=${estado.credenciaisEntregues} confirmIni=${estado.confirmacaoMsgInicialEnviada}`);

        const mensagensPacote = Array.isArray(estado.mensagensPendentes)
            ? estado.mensagensPendentes.splice(0)
            : [];

        const { rows: dncRows } = await pool.query(
            'SELECT do_not_contact FROM contatos WHERE id = $1 LIMIT 1',
            [contato]
        );
        const dnc = !!dncRows?.[0]?.do_not_contact;

        if (dnc) {
            const labels = await Promise.all(
                mensagensPacote.map(m => decidirOptLabel(m.texto || ''))
            );
            if (labels.some(l => l === 'REOPTIN')) {
                await setDoNotContact(contato, false);
                cancelarConfirmacaoOptOut(contato);
                if (typeof retomarEnvio === 'function') {
                    await delay(10000 + Math.floor(Math.random() * 5000));
                    await retomarEnvio(contato);
                }
                return;
            }
            console.log(`[${contato}] Ignorando processamento (do_not_contact=true).`);
            estado.mensagensPendentes = [];
            return;
        }

        const agora = Date.now();
        if (estado.etapa === 'encerrado' && estado.encerradoAte && agora < estado.encerradoAte) {
            console.log("[" + contato + "] Lead em timeout até " + new Date(estado.encerradoAte).toLocaleTimeString());
            return;
        }

        if (mensagensPacote.length === 0) {
            console.log("[" + contato + "] Nenhuma mensagem nova para processar");
            return;
        }

        if (await checarOptOutGlobal(contato, mensagensPacote.map(m => m.texto))) {
            await atualizarContato(contato, 'Sim', 'encerrado', '[OPTOUT]');
            return;
        }

        if (estado.etapa === 'abertura') {
            console.log("[" + contato + "] Processando etapa abertura");

            if (!estado.aberturaConcluida) {
                // ---------- MENSAGEM 1 (com dedupe) ----------
                const msg1Grupo1 = ['salve', 'opa', 'slv', 'e aí', 'eae', 'eai', 'fala', 'e ai', 'e ae', 'boa', 'boaa'];
                const msg1Grupo2 = [
                    'tô precisando de alguém pro trampo agora',
                    'preciso de alguém pra um trampo agora',
                    'tô precisando de alguém pra um trampo agora',
                    'preciso de alguém pro trampo agora',
                    'precisando de alguém pro trampo agora',
                    'precisando de alguém pra um trampo agora',
                    'to com vaga pra um trampo agora',
                    'tenho vaga pra um trampo agora',
                    'to com vaga pra um trampo',
                ];
                const msg1Grupo3 = [
                    'tá disponível?',
                    'tá disponível? 🍊',
                    'tá disponível? 🍊🍊',
                    'tá disponível? 🍊🍊🍊',

                    'vai poder fazer?',
                    'vai poder fazer? 🍊',
                    'vai poder fazer? 🍊🍊',
                    'vai poder fazer? 🍊🍊🍊',

                    'bora fazer?',
                    'bora fazer? 🍊',
                    'bora fazer? 🍊🍊',
                    'bora fazer? 🍊🍊🍊',

                    'consegue fazer?',
                    'consegue fazer? 🍊',
                    'consegue fazer? 🍊🍊',
                    'consegue fazer? 🍊🍊🍊',

                    'vamos fazer?',
                    'vamos fazer? 🍊',
                    'vamos fazer? 🍊🍊',
                    'vamos fazer? 🍊🍊🍊',

                    'vai fazer?',
                    'vai fazer? 🍊',
                    'vai fazer? 🍊🍊',
                    'vai fazer? 🍊🍊🍊',

                    'vai poder?',
                    'vai poder? 🍊',
                    'vai poder? 🍊🍊',
                    'vai poder? 🍊🍊🍊',

                    'consegue?',
                    'consegue? 🍊',
                    'consegue? 🍊🍊',
                    'consegue? 🍊🍊🍊',

                    'bora?',
                    'bora? 🍊',
                    'bora? 🍊🍊',
                    'bora? 🍊🍊🍊'
                ];

                const m1 = msg1Grupo1[Math.floor(Math.random() * msg1Grupo1.length)];
                const m2 = msg1Grupo2[Math.floor(Math.random() * msg1Grupo2.length)];
                const m3 = msg1Grupo3[Math.floor(Math.random() * msg1Grupo3.length)];
                let msg1 = `${m1}, ${m2}, ${m3}`;

                try {
                    const settings = await getBotSettings().catch(() => null);
                    const identEnabled = settings?.identity_enabled !== false;
                    let label = (settings?.identity_label || '').trim();
                    if (!label) {
                        const pieces = [];
                        if (settings?.support_email) pieces.push(settings.support_email);
                        if (settings?.support_phone) pieces.push(settings.support_phone);
                        if (settings?.support_url) pieces.push(settings.support_url);
                        if (pieces.length) label = `Suporte • ${pieces.join(' | ')}`;
                    }
                    if (identEnabled && label) msg1 = `${label} — ${msg1}`;
                    const optHintEnabled = settings?.optout_hint_enabled !== false;
                    const suffix = (settings?.optout_suffix || '· se não quiser: NÃO QUERO').trim();
                    if (optHintEnabled && suffix && !msg1.includes(suffix)) msg1 = `${msg1} ${suffix}`;
                } catch (e) {
                    console.error('[Abertura][inline selo/optout] erro:', e.message);
                }

                const pick = (arr) => Array.isArray(arr) && arr.length ? arr[Math.floor(Math.random() * arr.length)] : '';
                const msg2Grupo1 = [
                    'nem liga pro nome desse whats,',
                    'nem liga pro nome desse WhatsApp,',
                    'nem liga pro nome desse whatsapp,',
                    'nem liga pro nome desse whats aq,',
                    'nem liga pro nome desse WhatsApp aq,',
                    'nem liga pro nome desse whatsapp aq,',
                    'nem liga pro nome desse whats aqui,',
                    'nem liga pro nome desse WhatsApp aqui,',
                    'nem liga pro nome desse whatsapp aqui,',
                    'nem liga pro nome desse whats, beleza?',
                    'nem liga pro nome desse WhatsApp, beleza?',
                    'nem liga pro nome desse whatsapp, beleza?',
                    'nem liga pro nome desse whats, blz?',
                    'nem liga pro nome desse WhatsApp, blz?',
                    'nem liga pro nome desse whatsapp, blz?',
                    'nem liga pro nome desse whats, tranquilo?',
                    'nem liga pro nome desse WhatsApp, tranquilo?',
                    'nem liga pro nome desse whatsapp, tranquilo?',
                    'nem liga pro nome desse whats, dmr?',
                    'nem liga pro nome desse WhatsApp, dmr?',
                    'nem liga pro nome desse whatsapp, dmr?',
                    'n liga pro nome desse whats,',
                    'n liga pro nome desse WhatsApp,',
                    'n liga pro nome desse whatsapp,',
                    'n liga pro nome desse whats aq,',
                    'n liga pro nome desse WhatsApp aq,',
                    'n liga pro nome desse whatsapp aq,',
                    'n liga pro nome desse whats aqui,',
                    'n liga pro nome desse WhatsApp aqui,',
                    'n liga pro nome desse whatsapp aqui,',
                    'n liga pro nome desse whats, beleza?',
                    'n liga pro nome desse WhatsApp, beleza?',
                    'n liga pro nome desse whatsapp, beleza?',
                    'n liga pro nome desse whats, blz?',
                    'n liga pro nome desse WhatsApp, blz?',
                    'n liga pro nome desse whatsapp, blz?',
                    'n liga pro nome desse whats, tranquilo?',
                    'n liga pro nome desse WhatsApp, tranquilo?',
                    'n liga pro nome desse whatsapp, tranquilo?',
                    'n liga pro nome desse whats, dmr?',
                    'n liga pro nome desse WhatsApp, dmr?',
                    'n liga pro nome desse whatsapp, dmr?',
                    'não liga pro nome desse whats,',
                    'não liga pro nome desse WhatsApp,',
                    'não liga pro nome desse whatsapp,',
                    'não liga pro nome desse whats aq,',
                    'não liga pro nome desse WhatsApp aq,',
                    'não liga pro nome desse whatsapp aq,',
                    'não liga pro nome desse whats aqui,',
                    'não liga pro nome desse WhatsApp aqui,',
                    'não liga pro nome desse whatsapp aqui,',
                    'não liga pro nome desse whats, beleza?',
                    'não liga pro nome desse WhatsApp, beleza?',
                    'não liga pro nome desse whatsapp, beleza?',
                    'não liga pro nome desse whats, blz?',
                    'não liga pro nome desse WhatsApp, blz?',
                    'não liga pro nome desse whatsapp, blz?',
                    'não liga pro nome desse whats, tranquilo?',
                    'não liga pro nome desse WhatsApp, tranquilo?',
                    'não liga pro nome desse whatsapp, tranquilo?',
                    'não liga pro nome desse whats, dmr?',
                    'não liga pro nome desse WhatsApp, dmr?',
                    'não liga pro nome desse whatsapp, dmr?',
                    'ignora o nome desse whats,',
                    'ignora o nome desse WhatsApp,',
                    'ignora o nome desse whatsapp,',
                    'ignora o nome desse whats aq,',
                    'ignora o nome desse WhatsApp aq,',
                    'ignora o nome desse whatsapp aq,',
                    'ignora o nome desse whats aqui,',
                    'ignora o nome desse WhatsApp aqui,',
                    'ignora o nome desse whatsapp aqui,',
                    'ignora o nome desse whats, beleza?',
                    'ignora o nome desse WhatsApp, beleza?',
                    'ignora o nome desse whatsapp, beleza?',
                    'ignora o nome desse whats, blz?',
                    'ignora o nome desse WhatsApp, blz?',
                    'ignora o nome desse whatsapp, blz?',
                    'ignora o nome desse whats, tranquilo?',
                    'ignora o nome desse WhatsApp, tranquilo?',
                    'ignora o nome desse whatsapp, tranquilo?',
                    'ignora o nome desse whats, dmr?',
                    'ignora o nome desse WhatsApp, dmr?',
                    'ignora o nome desse whatsapp, dmr?',
                    'só ignora o nome desse whats,',
                    'só ignora o nome desse WhatsApp,',
                    'só ignora o nome desse whatsapp,',
                    'só ignora o nome desse whats aq,',
                    'só ignora o nome desse WhatsApp aq,',
                    'só ignora o nome desse whatsapp aq,',
                    'só ignora o nome desse whats aqui,',
                    'só ignora o nome desse WhatsApp aqui,',
                    'só ignora o nome desse whatsapp aqui,',
                    'só ignora o nome desse whats, beleza?',
                    'só ignora o nome desse WhatsApp, beleza?',
                    'só ignora o nome desse whatsapp, beleza?',
                    'só ignora o nome desse whats, blz?',
                    'só ignora o nome desse WhatsApp, blz?',
                    'só ignora o nome desse whatsapp, blz?',
                    'só ignora o nome desse whats, tranquilo?',
                    'só ignora o nome desse WhatsApp, tranquilo?',
                    'só ignora o nome desse whatsapp, tranquilo?',
                    'só ignora o nome desse whats, dmr?',
                    'só ignora o nome desse WhatsApp, dmr?',
                    'só ignora o nome desse whatsapp, dmr?'
                ];
                const msg2Grupo2 = [
                    'número empresarial q usamos pros trampo',
                    'número empresarial que usamos pros trampo',
                    'número comercial q usamos pros trampo',
                    'número comercial que usamos pros trampo',
                    'número business q usamos pros trampo',
                    'número business que usamos pros trampo',
                    'número empresarial q usamos pra trampos',
                    'número empresarial que usamos pra trampos',
                    'número comercial q usamos pra trampos',
                    'número comercial que usamos pra trampos',
                    'número business q usamos pra trampos',
                    'número business que usamos pra trampos',
                    'número empresarial q usamos pra um trampo',
                    'número empresarial que usamos pra um trampo',
                    'número comercial q usamos pra um trampo',
                    'número comercial que usamos pra um trampo',
                    'número business q usamos pra um trampo',
                    'número business que usamos pra um trampo',
                    'número empresarial q usamos pro trampo',
                    'número empresarial que usamos pro trampo',
                    'número comercial q usamos pro trampo',
                    'número comercial que usamos pro trampo',
                    'número business q usamos pro trampo',
                    'número business que usamos pro trampo',
                    'é número empresarial q usamos pros trampo',
                    'é número empresarial que usamos pros trampo',
                    'é número comercial q usamos pros trampo',
                    'é número comercial que usamos pros trampo',
                    'é número business q usamos pros trampo',
                    'é número business que usamos pros trampo',
                    'é número empresarial q usamos pra trampos',
                    'é número empresarial que usamos pra trampos',
                    'é número comercial q usamos pra trampos',
                    'é número comercial que usamos pra trampos',
                    'é número business q usamos pra trampos',
                    'é número business que usamos pra trampos',
                    'é número empresarial q usamos pra um trampo',
                    'é número empresarial que usamos pra um trampo',
                    'é número comercial q usamos pra um trampo',
                    'é número comercial que usamos pra um trampo',
                    'é número business q usamos pra um trampo',
                    'é número business que usamos pra um trampo',
                    'é número empresarial q usamos pro trampo',
                    'é número empresarial que usamos pro trampo',
                    'é número comercial q usamos pro trampo',
                    'é número comercial que usamos pro trampo',
                    'é número business q usamos pro trampo',
                    'é número business que usamos pro trampo',
                ];
                const msg2Grupo3 = [
                    'pode salvar como "Ryan"',
                    'pode salvar como "Ryan" mesmo',
                    'pode salvar como Ryan',
                    'pode salvar como Ryan mesmo',
                    'pode salvar com o nome Ryan',
                    'pode salvar com o nome "Ryan"',
                    'pode salvar com o nome "Ryan" mesmo',
                    'pode salvar com o nome Ryan mesmo',
                    'pode salvar esse número como "Ryan"',
                    'pode salvar esse número como Ryan',
                    'pode salvar esse número com o nome Ryan',
                    'pode salvar esse número com o nome "Ryan"',
                    'pode salvar esse número com o nome "Ryan" mesmo',
                    'pode salvar esse número como "Ryan" mesmo',
                    'salva como "Ryan"',
                    'salva como Ryan',
                    'salva com o nome Ryan',
                    'salva com o nome "Ryan"',
                    'salva com o nome "Ryan" mesmo',
                    'salva com o nome Ryan mesmo',
                    'salva esse número como "Ryan"',
                    'salva esse número como Ryan',
                    'salva esse número com o nome Ryan',
                    'salva esse número com o nome "Ryan"',
                    'salva esse número com o nome "Ryan" mesmo',
                    'salva esse número como "Ryan" mesmo',
                ];

                const msg2 = () => `${pick(msg2Grupo1)} ${pick(msg2Grupo2)}, ${pick(msg2Grupo3)}`;

                if (!estado.aberturaSequenciada) {
                    estado.aberturaSequenciada = true;
                    try {
                        if (!estado.msg1Enviada) {
                            estado.msg1Enviada = true;
                            await sendMessage(contato, msg1);
                            estado.historico.push({ role: 'assistant', content: msg1 });
                            await atualizarContato(contato, 'Sim', 'abertura', msg1);
                            console.log(`[${contato}] Mensagem inicial enviada: ${msg1}`);
                        }
                        if (!estado.msg2Enviada) {
                            await delay(7000 + Math.floor(Math.random() * 6000));
                            const m2 = msg2();
                            await sendMessage(contato, m2, { bypassBlock: false });
                            estado.historico.push({ role: 'assistant', content: m2 });
                            await atualizarContato(contato, 'Sim', 'abertura', m2);
                            console.log(`[${contato}] Segunda mensagem enviada: ${m2}`);
                            estado.msg2Enviada = true;
                        }
                        estado.aberturaConcluida = true;
                    } finally {
                        estado.aberturaSequenciada = false;
                    }
                }

                return;
            }
            if (mensagensPacote.length > 0 && estado.etapa === 'abertura') {
                estado.etapa = 'interesse';
                estado.primeiraRespostaPendente = false;
                await atualizarContato(contato, 'Sim', 'interesse', '[Avanço automático após abertura]');
                console.log(`[${contato}] Avanço automático para 'interesse'`);
            }
        }

        console.log(`[${contato}] Estado após processamento: etapa=${estado.etapa}, mensagensPendentes=${estado.mensagensPendentes.length}`);
    } catch (error) {
        console.error("[" + contato + "] Erro em processarMensagensPendentes: " + error.message);
        estadoContatos[contato].mensagensPendentes = [];
        const mensagem = 'vou ter que sair aqui, daqui a pouco te chamo';
        if (!estadoContatos[contato].sentKeys?.['erro.fallback']) {
            await enviarLinhaPorLinha(contato, mensagem);
            markSent(estadoContatos[contato], 'erro.fallback');
            await atualizarContato(contato, 'Sim', estadoContatos[contato].etapa, mensagem);
        }
    } finally {
        try {
            estado.enviandoMensagens = false;
            if (Array.isArray(estado.mensagensPendentes) && estado.mensagensPendentes.length > 0) {
                setImmediate(() => processarMensagensPendentes(contato).catch(console.error));
            }
        } catch (e) { console.error(e); }
    }
}

module.exports = { delay, gerarResposta, enviarLinhaPorLinha, inicializarEstado, criarUsuarioDjango, processarMensagensPendentes, sendMessage, gerarSenhaAleatoria, retomarEnvio, decidirOptLabel, cancelarConfirmacaoOptOut };