let estadoContatos = {};

module.exports = estadoContatos;
